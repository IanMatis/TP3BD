Pour se connecter a la BD, entrer les donnees de compte
dans les textbox du form1 et changer le type de sql dans
la fonction ConnectionBD dans la form1