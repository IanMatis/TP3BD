﻿namespace TrivialPursuit
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.btn_play = new System.Windows.Forms.Button();
            this.lbl_tourJoueur = new System.Windows.Forms.Label();
            this.btn_sport = new System.Windows.Forms.Button();
            this.btn_anime = new System.Windows.Forms.Button();
            this.btn_jeuxVideo = new System.Windows.Forms.Button();
            this.btn_animaux = new System.Windows.Forms.Button();
            this.btn_orange = new System.Windows.Forms.Button();
            this.btn_jaune = new System.Windows.Forms.Button();
            this.btn_mauve = new System.Windows.Forms.Button();
            this.btn_bleu = new System.Windows.Forms.Button();
            this.btn_rep1 = new System.Windows.Forms.Button();
            this.btn_rep2 = new System.Windows.Forms.Button();
            this.btn_rep3 = new System.Windows.Forms.Button();
            this.btn_rep4 = new System.Windows.Forms.Button();
            this.lbl_joueur1 = new System.Windows.Forms.Label();
            this.lbl_Joueur2 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btn_o1 = new System.Windows.Forms.Button();
            this.btn_j1 = new System.Windows.Forms.Button();
            this.btn_b1 = new System.Windows.Forms.Button();
            this.btn_m1 = new System.Windows.Forms.Button();
            this.btn_m2 = new System.Windows.Forms.Button();
            this.btn_b2 = new System.Windows.Forms.Button();
            this.btn_j2 = new System.Windows.Forms.Button();
            this.btn_o2 = new System.Windows.Forms.Button();
            this.lbl_question = new System.Windows.Forms.Label();
            this.lbl_winner = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_play
            // 
            this.btn_play.Location = new System.Drawing.Point(513, 27);
            this.btn_play.Name = "btn_play";
            this.btn_play.Size = new System.Drawing.Size(99, 87);
            this.btn_play.TabIndex = 0;
            this.btn_play.Text = "Start";
            this.btn_play.UseVisualStyleBackColor = true;
            this.btn_play.Click += new System.EventHandler(this.btn_play_Click);
            // 
            // lbl_tourJoueur
            // 
            this.lbl_tourJoueur.AutoSize = true;
            this.lbl_tourJoueur.Location = new System.Drawing.Point(23, 192);
            this.lbl_tourJoueur.Name = "lbl_tourJoueur";
            this.lbl_tourJoueur.Size = new System.Drawing.Size(61, 13);
            this.lbl_tourJoueur.TabIndex = 1;
            this.lbl_tourJoueur.Text = "TourJoueur";
            // 
            // btn_sport
            // 
            this.btn_sport.BackColor = System.Drawing.Color.White;
            this.btn_sport.Enabled = false;
            this.btn_sport.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_sport.Location = new System.Drawing.Point(7, 33);
            this.btn_sport.Name = "btn_sport";
            this.btn_sport.Size = new System.Drawing.Size(170, 33);
            this.btn_sport.TabIndex = 2;
            this.btn_sport.Text = "Sport";
            this.btn_sport.UseVisualStyleBackColor = false;
            this.btn_sport.Click += new System.EventHandler(this.btn_sport_Click);
            // 
            // btn_anime
            // 
            this.btn_anime.BackColor = System.Drawing.Color.White;
            this.btn_anime.Enabled = false;
            this.btn_anime.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_anime.Location = new System.Drawing.Point(7, 64);
            this.btn_anime.Name = "btn_anime";
            this.btn_anime.Size = new System.Drawing.Size(170, 33);
            this.btn_anime.TabIndex = 3;
            this.btn_anime.Text = "Anime";
            this.btn_anime.UseVisualStyleBackColor = false;
            this.btn_anime.Click += new System.EventHandler(this.btn_anime_Click);
            // 
            // btn_jeuxVideo
            // 
            this.btn_jeuxVideo.BackColor = System.Drawing.Color.White;
            this.btn_jeuxVideo.Enabled = false;
            this.btn_jeuxVideo.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_jeuxVideo.Location = new System.Drawing.Point(7, 94);
            this.btn_jeuxVideo.Name = "btn_jeuxVideo";
            this.btn_jeuxVideo.Size = new System.Drawing.Size(170, 33);
            this.btn_jeuxVideo.TabIndex = 4;
            this.btn_jeuxVideo.Text = "Jeux Video";
            this.btn_jeuxVideo.UseVisualStyleBackColor = false;
            this.btn_jeuxVideo.Click += new System.EventHandler(this.btn_jeuxVideo_Click);
            // 
            // btn_animaux
            // 
            this.btn_animaux.BackColor = System.Drawing.Color.White;
            this.btn_animaux.Enabled = false;
            this.btn_animaux.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_animaux.Location = new System.Drawing.Point(7, 125);
            this.btn_animaux.Name = "btn_animaux";
            this.btn_animaux.Size = new System.Drawing.Size(170, 33);
            this.btn_animaux.TabIndex = 5;
            this.btn_animaux.Text = "Animaux";
            this.btn_animaux.UseVisualStyleBackColor = false;
            this.btn_animaux.Click += new System.EventHandler(this.btn_animaux_Click);
            // 
            // btn_orange
            // 
            this.btn_orange.BackColor = System.Drawing.Color.Orange;
            this.btn_orange.Enabled = false;
            this.btn_orange.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_orange.Location = new System.Drawing.Point(175, 33);
            this.btn_orange.Name = "btn_orange";
            this.btn_orange.Size = new System.Drawing.Size(33, 33);
            this.btn_orange.TabIndex = 6;
            this.btn_orange.UseVisualStyleBackColor = false;
            // 
            // btn_jaune
            // 
            this.btn_jaune.BackColor = System.Drawing.Color.Yellow;
            this.btn_jaune.Enabled = false;
            this.btn_jaune.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_jaune.Location = new System.Drawing.Point(175, 64);
            this.btn_jaune.Name = "btn_jaune";
            this.btn_jaune.Size = new System.Drawing.Size(33, 33);
            this.btn_jaune.TabIndex = 7;
            this.btn_jaune.UseVisualStyleBackColor = false;
            // 
            // btn_mauve
            // 
            this.btn_mauve.BackColor = System.Drawing.Color.Purple;
            this.btn_mauve.Enabled = false;
            this.btn_mauve.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_mauve.Location = new System.Drawing.Point(175, 125);
            this.btn_mauve.Name = "btn_mauve";
            this.btn_mauve.Size = new System.Drawing.Size(33, 33);
            this.btn_mauve.TabIndex = 8;
            this.btn_mauve.UseVisualStyleBackColor = false;
            // 
            // btn_bleu
            // 
            this.btn_bleu.BackColor = System.Drawing.Color.Blue;
            this.btn_bleu.Enabled = false;
            this.btn_bleu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bleu.Location = new System.Drawing.Point(175, 94);
            this.btn_bleu.Name = "btn_bleu";
            this.btn_bleu.Size = new System.Drawing.Size(33, 33);
            this.btn_bleu.TabIndex = 9;
            this.btn_bleu.UseVisualStyleBackColor = false;
            // 
            // btn_rep1
            // 
            this.btn_rep1.Location = new System.Drawing.Point(81, 274);
            this.btn_rep1.Name = "btn_rep1";
            this.btn_rep1.Size = new System.Drawing.Size(225, 75);
            this.btn_rep1.TabIndex = 10;
            this.btn_rep1.UseVisualStyleBackColor = true;
            this.btn_rep1.Click += new System.EventHandler(this.btn_reponses);
            // 
            // btn_rep2
            // 
            this.btn_rep2.Location = new System.Drawing.Point(312, 274);
            this.btn_rep2.Name = "btn_rep2";
            this.btn_rep2.Size = new System.Drawing.Size(225, 75);
            this.btn_rep2.TabIndex = 11;
            this.btn_rep2.UseVisualStyleBackColor = true;
            this.btn_rep2.Click += new System.EventHandler(this.btn_reponses);
            // 
            // btn_rep3
            // 
            this.btn_rep3.Location = new System.Drawing.Point(81, 355);
            this.btn_rep3.Name = "btn_rep3";
            this.btn_rep3.Size = new System.Drawing.Size(225, 75);
            this.btn_rep3.TabIndex = 12;
            this.btn_rep3.UseVisualStyleBackColor = true;
            this.btn_rep3.Click += new System.EventHandler(this.btn_reponses);
            // 
            // btn_rep4
            // 
            this.btn_rep4.Location = new System.Drawing.Point(312, 355);
            this.btn_rep4.Name = "btn_rep4";
            this.btn_rep4.Size = new System.Drawing.Size(225, 75);
            this.btn_rep4.TabIndex = 13;
            this.btn_rep4.UseVisualStyleBackColor = true;
            this.btn_rep4.Click += new System.EventHandler(this.btn_reponses);
            // 
            // lbl_joueur1
            // 
            this.lbl_joueur1.AutoSize = true;
            this.lbl_joueur1.Location = new System.Drawing.Point(293, 37);
            this.lbl_joueur1.Name = "lbl_joueur1";
            this.lbl_joueur1.Size = new System.Drawing.Size(45, 13);
            this.lbl_joueur1.TabIndex = 15;
            this.lbl_joueur1.Text = "Joueur1";
            // 
            // lbl_Joueur2
            // 
            this.lbl_Joueur2.AutoSize = true;
            this.lbl_Joueur2.Location = new System.Drawing.Point(293, 101);
            this.lbl_Joueur2.Name = "lbl_Joueur2";
            this.lbl_Joueur2.Size = new System.Drawing.Size(45, 13);
            this.lbl_Joueur2.TabIndex = 16;
            this.lbl_Joueur2.Text = "Joueur2";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(339, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 13);
            this.label2.TabIndex = 23;
            this.label2.Text = "Pointage";
            // 
            // btn_o1
            // 
            this.btn_o1.BackColor = System.Drawing.Color.Orange;
            this.btn_o1.Enabled = false;
            this.btn_o1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_o1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_o1.Location = new System.Drawing.Point(296, 58);
            this.btn_o1.Name = "btn_o1";
            this.btn_o1.Size = new System.Drawing.Size(33, 33);
            this.btn_o1.TabIndex = 27;
            this.btn_o1.Text = "0";
            this.btn_o1.UseVisualStyleBackColor = false;
            // 
            // btn_j1
            // 
            this.btn_j1.BackColor = System.Drawing.Color.Yellow;
            this.btn_j1.Enabled = false;
            this.btn_j1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_j1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_j1.Location = new System.Drawing.Point(328, 58);
            this.btn_j1.Name = "btn_j1";
            this.btn_j1.Size = new System.Drawing.Size(33, 33);
            this.btn_j1.TabIndex = 28;
            this.btn_j1.Text = "0";
            this.btn_j1.UseVisualStyleBackColor = false;
            // 
            // btn_b1
            // 
            this.btn_b1.BackColor = System.Drawing.Color.Blue;
            this.btn_b1.Enabled = false;
            this.btn_b1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_b1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_b1.Location = new System.Drawing.Point(360, 58);
            this.btn_b1.Name = "btn_b1";
            this.btn_b1.Size = new System.Drawing.Size(33, 33);
            this.btn_b1.TabIndex = 29;
            this.btn_b1.Text = "0";
            this.btn_b1.UseVisualStyleBackColor = false;
            // 
            // btn_m1
            // 
            this.btn_m1.BackColor = System.Drawing.Color.Purple;
            this.btn_m1.Enabled = false;
            this.btn_m1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_m1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_m1.Location = new System.Drawing.Point(392, 58);
            this.btn_m1.Name = "btn_m1";
            this.btn_m1.Size = new System.Drawing.Size(33, 33);
            this.btn_m1.TabIndex = 30;
            this.btn_m1.Text = "0";
            this.btn_m1.UseVisualStyleBackColor = false;
            // 
            // btn_m2
            // 
            this.btn_m2.BackColor = System.Drawing.Color.Purple;
            this.btn_m2.Enabled = false;
            this.btn_m2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_m2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_m2.Location = new System.Drawing.Point(392, 125);
            this.btn_m2.Name = "btn_m2";
            this.btn_m2.Size = new System.Drawing.Size(33, 33);
            this.btn_m2.TabIndex = 34;
            this.btn_m2.Text = "0";
            this.btn_m2.UseVisualStyleBackColor = false;
            // 
            // btn_b2
            // 
            this.btn_b2.BackColor = System.Drawing.Color.Blue;
            this.btn_b2.Enabled = false;
            this.btn_b2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_b2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_b2.Location = new System.Drawing.Point(360, 125);
            this.btn_b2.Name = "btn_b2";
            this.btn_b2.Size = new System.Drawing.Size(33, 33);
            this.btn_b2.TabIndex = 33;
            this.btn_b2.Text = "0";
            this.btn_b2.UseVisualStyleBackColor = false;
            // 
            // btn_j2
            // 
            this.btn_j2.BackColor = System.Drawing.Color.Yellow;
            this.btn_j2.Enabled = false;
            this.btn_j2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_j2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_j2.Location = new System.Drawing.Point(328, 125);
            this.btn_j2.Name = "btn_j2";
            this.btn_j2.Size = new System.Drawing.Size(33, 33);
            this.btn_j2.TabIndex = 32;
            this.btn_j2.Text = "0";
            this.btn_j2.UseVisualStyleBackColor = false;
            // 
            // btn_o2
            // 
            this.btn_o2.BackColor = System.Drawing.Color.Orange;
            this.btn_o2.Enabled = false;
            this.btn_o2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_o2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_o2.Location = new System.Drawing.Point(296, 125);
            this.btn_o2.Name = "btn_o2";
            this.btn_o2.Size = new System.Drawing.Size(33, 33);
            this.btn_o2.TabIndex = 31;
            this.btn_o2.Text = "0";
            this.btn_o2.UseVisualStyleBackColor = false;
            // 
            // lbl_question
            // 
            this.lbl_question.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_question.Location = new System.Drawing.Point(0, 0);
            this.lbl_question.Name = "lbl_question";
            this.lbl_question.Size = new System.Drawing.Size(620, 448);
            this.lbl_question.TabIndex = 35;
            this.lbl_question.Text = "Question:";
            this.lbl_question.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_winner
            // 
            this.lbl_winner.AutoSize = true;
            this.lbl_winner.Location = new System.Drawing.Point(23, 231);
            this.lbl_winner.Name = "lbl_winner";
            this.lbl_winner.Size = new System.Drawing.Size(84, 13);
            this.lbl_winner.TabIndex = 36;
            this.lbl_winner.Text = "Le gagnant est :";
            this.lbl_winner.Visible = false;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(620, 448);
            this.Controls.Add(this.lbl_winner);
            this.Controls.Add(this.btn_m2);
            this.Controls.Add(this.btn_b2);
            this.Controls.Add(this.btn_j2);
            this.Controls.Add(this.btn_o2);
            this.Controls.Add(this.btn_m1);
            this.Controls.Add(this.btn_b1);
            this.Controls.Add(this.btn_j1);
            this.Controls.Add(this.btn_o1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lbl_Joueur2);
            this.Controls.Add(this.lbl_joueur1);
            this.Controls.Add(this.btn_rep4);
            this.Controls.Add(this.btn_rep3);
            this.Controls.Add(this.btn_rep2);
            this.Controls.Add(this.btn_rep1);
            this.Controls.Add(this.btn_bleu);
            this.Controls.Add(this.btn_mauve);
            this.Controls.Add(this.btn_jaune);
            this.Controls.Add(this.btn_orange);
            this.Controls.Add(this.btn_animaux);
            this.Controls.Add(this.btn_jeuxVideo);
            this.Controls.Add(this.btn_anime);
            this.Controls.Add(this.btn_sport);
            this.Controls.Add(this.lbl_tourJoueur);
            this.Controls.Add(this.btn_play);
            this.Controls.Add(this.lbl_question);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Trivial Pursuit";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form2_FormClosed);
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_play;
        private System.Windows.Forms.Label lbl_tourJoueur;
        private System.Windows.Forms.Button btn_sport;
        private System.Windows.Forms.Button btn_anime;
        private System.Windows.Forms.Button btn_jeuxVideo;
        private System.Windows.Forms.Button btn_animaux;
        private System.Windows.Forms.Button btn_orange;
        private System.Windows.Forms.Button btn_jaune;
        private System.Windows.Forms.Button btn_mauve;
        private System.Windows.Forms.Button btn_bleu;
        private System.Windows.Forms.Button btn_rep1;
        private System.Windows.Forms.Button btn_rep2;
        private System.Windows.Forms.Button btn_rep3;
        private System.Windows.Forms.Button btn_rep4;
        private System.Windows.Forms.Label lbl_joueur1;
        private System.Windows.Forms.Label lbl_Joueur2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_o1;
        private System.Windows.Forms.Button btn_j1;
        private System.Windows.Forms.Button btn_b1;
        private System.Windows.Forms.Button btn_m1;
        private System.Windows.Forms.Button btn_m2;
        private System.Windows.Forms.Button btn_b2;
        private System.Windows.Forms.Button btn_j2;
        private System.Windows.Forms.Button btn_o2;
        private System.Windows.Forms.Label lbl_question;
        private System.Windows.Forms.Label lbl_winner;
    }
}